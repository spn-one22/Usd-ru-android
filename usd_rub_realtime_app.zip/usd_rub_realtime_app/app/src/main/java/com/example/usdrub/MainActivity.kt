package com.example.usdrub

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.usdrub.databinding.ActivityMainBinding
import kotlinx.coroutines.*
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET

data class RateResponse(val rates: Map<String, Double>)

interface ApiService {
    @GET("latest.json?app_id=demo") // demo key
    suspend fun getRates(): RateResponse
}

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val retrofit = Retrofit.Builder()
            .baseUrl("https://openexchangerates.org/api/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        val service = retrofit.create(ApiService::class.java)

        GlobalScope.launch(Dispatchers.Main) {
            try {
                val result = withContext(Dispatchers.IO) { service.getRates() }
                val usdToRub = result.rates["RUB"] ?: 0.0
                binding.textView.text = "1 USD = %.2f RUB".format(usdToRub)
            } catch (e: Exception) {
                binding.textView.text = "Ошибка загрузки курса"
            }
        }
    }
}
